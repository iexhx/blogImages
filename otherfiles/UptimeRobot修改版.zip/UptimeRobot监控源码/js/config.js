var __apiKeys = [
	'xxxxxx', //这里设置api密钥
	'xxxxxx', //这里设置api密钥

];
//https://uptimerobot.com/ 设置要监控的域名或者ip 获取到key


// refresh interval (in seconds)
var __refresh = 180;
